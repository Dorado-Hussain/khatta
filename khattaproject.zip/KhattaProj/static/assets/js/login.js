// Initiliazing Global Variables
let hideShowPassword = document.getElementsByClassName("password-eye")[0];
let passwordElement = document.getElementById("password")
let passwordhide = false;


// Handing Events
hideShowPassword.addEventListener("click", (element)=>{
    if (passwordhide === false){
        hideShowPassword.classList.replace("fa-eye-slash", "fa-eye");
        passwordhide = true;
        passwordElement.setAttribute("type", "text");
    } 
    else{
        hideShowPassword.classList.replace("fa-eye", "fa-eye-slash");
        passwordElement.setAttribute("type", "password");
        passwordhide = false;
    }
});