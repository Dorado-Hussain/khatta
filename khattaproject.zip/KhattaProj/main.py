from flask import render_template, Flask, request, session, redirect, flash, jsonify
from passlib.hash import sha256_crypt
from flask_sqlalchemy import SQLAlchemy
from datetime import date
from datetime import datetime
import json


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/khatta'
app.secret_key = "khattaprojiskey"
db = SQLAlchemy(app)

## Date
# Get the current date
current_date = date.today()

# Extract date components
current_year = current_date.year
current_month = current_date.month
current_day = current_date.day


class Login(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), nullable=False, unique=False)
    password = db.Column(db.String(256), nullable=False, unique=False)
    user_access = db.Column(db.String(80), nullable=False, unique=False)
    ip_address = db.Column(db.String(80), nullable=False, unique=False)
    date = db.Column(db.DateTime, default=datetime.utcnow)


class addcustomer(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=False)
    address = db.Column(db.String(120), nullable=False, unique=False)
    city = db.Column(db.String(120), nullable=False, unique=False)
    phone = db.Column(db.String(120), nullable=False, unique=False)
    old_udhaar = db.Column(db.String(120), nullable=False, unique=False)


# class addvendor(db.Model):
#     sno = db.Column(db.Integer, primary_key=True)
#     name = db.Column(db.String(120), nullable=False, unique=False)
#     address = db.Column(db.String(120), nullable=False, unique=False)
#     city = db.Column(db.String(120), nullable=False, unique=False)
#     phone = db.Column(db.String(120), nullable=False, unique=False)
#     old_udhaar = db.Column(db.String(120), nullable=False, unique=False)


class additem(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    item_name = db.Column(db.String(120), nullable=False, unique=False)


# class searchname(db.Model):
#     sno = db.Column(db.Integer, primary_key=True)
#     code = db.Column(db.String(120), nullable=False, unique=False)
#     name = db.Column(db.String(120), nullable=False, unique=False)
#


class loanpayment(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=False)
    payment = db.Column(db.String(120), nullable=False, unique=False)
    description = db.Column(db.String(600), nullable=False, unique=False)
    voucher_id = db.Column(db.String(120), nullable=False, unique=False)
    date = db.Column(default=datetime.utcnow())


class loan_receive_payment(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=False)
    payment = db.Column(db.String(120), nullable=False, unique=False)
    description = db.Column(db.String(600), nullable=False, unique=False)
    voucher_id = db.Column(db.String(120), nullable=False, unique=False)
    date = db.Column(default=datetime.utcnow())
    raqam = db.Column(db.String(120))
    jama_raqam = db.Column(db.String(120), nullable=False, unique=False)
    udhaar = db.Column(db.String(120), nullable=False, unique=False)


class mycheck(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=False)
    payment = db.Column(db.String(120), nullable=False, unique=False)
    description = db.Column(db.String(600), nullable=False, unique=False)
    voucher_id = db.Column(db.String(120), nullable=False, unique=False)
    date = db.Column(default=datetime.utcnow())
    raqam = db.Column(db.String(120))
    jama_raqam = db.Column(db.String(120), nullable=False, unique=False)
    udhaar = db.Column(db.String(120), nullable=False, unique=False)


class receivepayment(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False, unique=False)
    payment = db.Column(db.String(120), nullable=False, unique=False)
    description = db.Column(db.String(600), nullable=False, unique=False)
    voucher_id = db.Column(db.String(120), nullable=False, unique=False)
    date = db.Column(default=datetime.utcnow())


class sale_invoice(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(120), nullable=False, unique=False)
    item_name = db.Column(db.String(120), nullable=False, unique=False)
    quantity = db.Column(db.String(120), nullable=False, unique=False)
    price = db.Column(db.String(120), nullable=False, unique=False)
    discount = db.Column(db.String(120), nullable=False, unique=False)
    total_amount = db.Column(db.String(120), nullable=False, unique=False)
    previous_amount = db.Column(db.String(120), nullable=False, unique=False)
    bill_no = db.Column(db.String(120), nullable=False, unique=False)
    date = db.Column(default=datetime.utcnow())
    jama_raqam = db.Column(db.String(120), nullable=False, unique=False)


class purchase_invoice(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    customer_name = db.Column(db.String(120), nullable=False, unique=False)
    item_name = db.Column(db.String(120), nullable=False, unique=False)
    quantity = db.Column(db.String(120), nullable=False, unique=False)
    price = db.Column(db.String(120), nullable=False, unique=False)
    discount = db.Column(db.String(120), nullable=False, unique=False)
    total_amount = db.Column(db.String(120), nullable=False, unique=False)
    previous_amount = db.Column(db.String(120), nullable=False, unique=False)
    bill_no = db.Column(db.String(120), nullable=False, unique=False)
    date = db.Column(default=datetime.utcnow())
    jama_raqam = db.Column(db.String(120), nullable=False, unique=False)


class online_payment(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    sender_name = db.Column(db.String(120), nullable=False, unique=False)
    receiver_name = db.Column(db.String(120), nullable=False, unique=False)
    amount = db.Column(db.String(120), nullable=False, unique=False)
    bank_name = db.Column(db.String(120), nullable=False, unique=False)
    account_no = db.Column(db.String(120), nullable=False, unique=False)
    description = db.Column(db.String(120), nullable=False, unique=False)
    bill_no = db.Column(db.String(120), nullable=False, unique=False)



@app.route("/", methods=['GET', 'POST'])
def homepage():
    if "username" in session:
        return redirect("/dashboard")

    else:
        if request.method == 'POST':
            fetch_username = request.form.get("username")
            fetch_password = request.form.get("password")

            fetch_database_data = Login.query.filter_by(username=fetch_username).first()

            if fetch_database_data:
                database_pass = fetch_database_data.password

                if sha256_crypt.verify(fetch_password, database_pass):
                    session['username'] = fetch_username
                    return redirect("/dashboard")
                else:
                    flash("Password is incorrect !", "error")
                    return redirect("/")

            else:
                flash("Username is incorrect !", "error")
                return redirect("/")

    return render_template("index.html")


@app.route("/dashboard")
def dashboardpage():
    if "username" in session:
        return render_template("dashboard.html")
    else:
        return redirect("/")


@app.route("/logout")
def logOut():
    session.pop("username", None)
    return redirect("/")


@app.route("/change-password", methods=['GET', 'POST'])
def changePassword():
    if "username" in session:
        if request.method == 'POST':
            fetch_username = request.form.get('username')
            fetch_old_password = request.form.get('password')
            fetch_new_password = request.form.get('cnpassword')
            fetch_cn_password = request.form.get('cn-password')

            if fetch_new_password == fetch_cn_password:
                fetch_database_username = Login.query.filter_by(username=fetch_username).first()
                if fetch_database_username:
                    fetch_database_password = fetch_database_username.password
                    if sha256_crypt.verify(fetch_old_password, fetch_database_password):
                        fetch_database_username.password = sha256_crypt.encrypt(fetch_cn_password)
                        db.session.commit()
                        flash("Password Changes Successfully.", "success")
                        return redirect("/change-password")
                    else:
                        flash("Old password is incorrect.", "error")
                        return redirect("/change-password")
                else:
                    flash("Username does not exist..", "error")
                    return redirect("/change-password")
            else:
                flash("Both password does not match.", "error")
                return redirect("/change-password")

        return render_template("change_password.html")
    else:
        return redirect("/")


@app.route("/new-user", methods=['GET', 'POST'])
def newUser():
    if "username" in session:
        fetch_user_access = Login.query.filter_by(username=session['username']).first()

        if fetch_user_access.user_access == "admin":
            if request.method == 'POST':
                fetch_username = request.form.get('username')
                fetch_password = request.form.get('password')
                cn_password = request.form.get('cnpassword')

                if fetch_password == cn_password:
                    enc_password = sha256_crypt.encrypt(cn_password)
                    fetch_database = Login.query.filter_by(username=fetch_username).first()
                    if fetch_database:
                        flash("username already exist.", "error")
                        return redirect("/new-user")
                    else:
                        add_data = Login(
                            username=fetch_username,
                            password=enc_password,
                            ip_address=request.remote_addr,
                            user_access="normal"
                        )

                        db.session.add(add_data)
                        db.session.commit()
                        flash("User added successfully", "success")
                        return redirect("/new-user")
                else:
                    flash("Both password does not match", "error")
                    return redirect("/new-user")
        else:
            return redirect("/dashboard")
        return render_template("newuser.html")
    else:
        return redirect("/")


@app.route("/user-remove/<string:id_slug>", methods=['GET', 'POST'])
def removeUser(id_slug):
    if "username" in session:
        fetch_database_sno = Login.query.filter_by(sno=id_slug).first()
        db.session.delete(fetch_database_sno)
        db.session.commit()
        return redirect("/user-remove")
    else:
        return redirect("/")


@app.route("/user-remove")
def removeuser():
    if "username" in session:
        fetch_user_access = Login.query.filter_by(username=session['username']).first()
        if fetch_user_access.user_access == "admin":
            fetch_all_users = Login.query.filter_by().all()
            return render_template("user_remove.html",
                                   alldata=fetch_all_users, current_user=session['username'])
        return redirect("/")
    else:
        return redirect("/")


@app.route("/add-customer", methods=['GET', 'POST'])
def addCustomerPage():
    if "username" in session:
        fetch_add_customer = addcustomer.query.filter_by().all()
        if request.method == "POST":
            name = request.form.get("name")
            address = request.form.get("address")
            city = request.form.get("city")
            phone = request.form.get("phone")

            fetch_use_existence = addcustomer.query.filter_by(name=name).first()
            if fetch_use_existence:
                return render_template("Add_customer.html",
                                       error_detail="User already exist.",
                                       displ="block")
            else:
                add_data = addcustomer(name=name, address=address,
                                       city=city, phone=phone, old_udhaar=0)
                db.session.add(add_data)
                db.session.commit()
                return render_template("Add_customer.html",
                                       success_detail="Customer added successfully.",
                                       sc_displ="block")

        return render_template("Add_customer.html")
    else:
        return redirect("/")






# @app.route("/add-vendor", methods=['GET', 'POST'])
# def addVendorPage():
#     if "username" in session:
#         fetch_add_vendor = addvendor.query.filter_by().all()
#         if request.method == "POST":
#             name = request.form.get("name")
#             address = request.form.get("address")
#             city = request.form.get("city")
#             phone = request.form.get("phone")
#
#             add_data = addvendor(name=name, address=address, city=city,
#                                  phone=phone)
#             db.session.add(add_data)
#             db.session.commit()
#             return render_template("vendor.html",
#                                    success_detail="Vendor added successfully",
#                                    sc_displ="block")
#
#         return render_template("vendor.html")
#     else:
#         return redirect("/")
#

@app.route("/add-item", methods=['GET', 'POST'])
def addItemPage():
    if "username" in session:
        fetch_add_item = additem.query.filter_by().all()
        if request.method == "POST":
            name = request.form.get("itemname")

            add_data = additem(item_name=name)
            db.session.add(add_data)
            db.session.commit()
            return render_template("Add_item.html",
                                   success_detail="Item added successfully",
                                   sc_displ="block")

        return render_template("Add_item.html")
    else:
        return redirect("/")


@app.route("/sale-invoice", methods=['GET', 'POST'])
def saleInvoicePage():
    if "username" in session:
        # Get the current date
        current_date = date.today()

        # Extract date components
        current_year = current_date.year
        current_month = current_date.month
        current_day = current_date.day

        fetch_users_data = addcustomer.query.filter_by().all()
        fetch_items_data = additem.query.filter_by().all()
        fetch_sale_invoice = sale_invoice.query.filter_by().all()

        if len(fetch_sale_invoice) <= 0:
            bill_no = 1
        else:
            bill_no = int(fetch_sale_invoice[::-1][0].bill_no) + 1

        return render_template("sale_invoice.html", users=fetch_users_data,
                               items=fetch_items_data, date=current_day, month=current_month,
                               year=current_year, bill_no=bill_no)
    else:
        return redirect("/")


@app.route("/loan-payment", methods=['GET', 'POST'])
def paymentPage():
    if "username" in session:

        fetch_users_data = addcustomer.query.filter_by().all()

        fetch_old_khatta_users = loanpayment.query.filter_by().all()

        if len(fetch_old_khatta_users) <= 0:
            voucher_id = 3000
        else:
            voucher_id = int(fetch_old_khatta_users[::-1][0].voucher_id) + 1

        current_date = date.today()

        # Extract date components
        current_year = current_date.year
        current_month = current_date.month
        current_day = current_date.day

        return render_template("loan_payment.html", dates=current_day,
                               month=current_month, year=current_year, users=fetch_users_data,
                               voucher_id=voucher_id)
    else:
        return redirect("/")


@app.route("/cashbook", methods=['GET', 'POST'])
def cashbook():
    if "username" in session:
        return render_template("cashbook.html")
    else:
        return redirect("/")


@app.route("/online-payment", methods=['GET', 'POST'])
def onlinePayment():
    if "username" in session:

        fetch_online_payment = online_payment.query.filter_by().all()
        fetch_add_customer = addcustomer.query.filter_by().all()

        if len(fetch_online_payment) <= 0:
            bill_no = 11000
        else:
            bill_no = int(fetch_online_payment[::-1][0].bill_no) + 1

        return render_template("online_payment.html", dates=current_day,
                               month=current_month, year=current_year, voucher_id=bill_no, users=fetch_add_customer)
    else:
        return redirect("/")


@app.route('/save_online_payment', methods=['GET', 'POST'])
def saveOnlinePayment():
    try:
        data = request.json

        fetch_online_payment = online_payment.query.filter_by().all()

        if len(fetch_online_payment) <= 0:
            bill_no = 11000
        else:
            bill_no = int(fetch_online_payment[::-1][0].bill_no) + 1



        for i in data:
            add_data = online_payment(sender_name=i['sender_name'], receiver_name=i['receiver_name'], amount=i['amount'],
                                      bank_name=i['bank_name'], account_no=i['title'], description=i['description'],
                                      bill_no=bill_no)
            db.session.add(add_data)
            db.session.commit()

            add_new_data = loan_receive_payment(name=i['sender_name'], payment=i['amount'], description=i['description'],
                                                voucher_id=bill_no, date=current_date, raqam='online', jama_raqam=0, udhaar=0)
            db.session.add(add_new_data)
            db.session.commit()

        response = {'status': 'success', 'message': 'Data saved successfully'}
        return redirect("/online-payment")
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route("/purchase-invoice", methods=['GET', 'POST'])
def purchaseInvoice():
    if "username" in session:
        current_date = date.today()

        # Extract date components
        current_year = current_date.year
        current_month = current_date.month
        current_day = current_date.day

        fetch_users_data = addcustomer.query.filter_by().all()
        fetch_items_data = additem.query.filter_by().all()
        fetch_sale_invoice = purchase_invoice.query.filter_by().all()

        if len(fetch_sale_invoice) <= 0:
            bill_no = 2000
        else:
            bill_no = int(fetch_sale_invoice[::-1][0].bill_no) + 1

        return render_template("purchase_invoice.html", users=fetch_users_data,
                               items=fetch_items_data, date=current_day, month=current_month,
                               year=current_year, bill_no=bill_no)

        # return render_template("purchase_invoice.html")
    else:
        return redirect("/")


@app.route("/receive-payment", methods=['GET', 'POST'])
def receivePayment():
    if "username" in session:

        fetch_users_data = addcustomer.query.filter_by().all()

        fetch_old_khatta_users = receivepayment.query.filter_by().all()

        if len(fetch_old_khatta_users) <= 0:
            voucher_id = 4000
        else:
            voucher_id = int(fetch_old_khatta_users[::-1][0].voucher_id) + 1

        current_date = date.today()

        # Extract date components
        current_year = current_date.year
        current_month = current_date.month
        current_day = current_date.day

        return render_template("Recive_payment.html", dates=current_day,
                               month=current_month, year=current_year, users=fetch_users_data,
                               voucher_id=voucher_id)
    else:
        return redirect("/")


@app.route("/khata", methods=['GET', 'POST'])
def khattaPage():
    if "username" in session:
        if request.method == 'POST':
            name = request.form.get("user-name")
            date_to = request.form.get("dateTo")
            date_from = request.form.get("dateFrom")

            myDate = current_date

            fetch_old_udhaar = addcustomer.query.filter_by(name=name).first().old_udhaar

            # fetch_my_data = loan_receive_payment.query.filter_by(name=name).all()
            fetch_my_data = loan_receive_payment.query.filter_by(name=name).filter(
                loan_receive_payment.date.between(date_from, myDate)).all()

            total_receive = 0
            total_loan = 0
            total_net_amount = 0

            bill_is = 0
            newbill = []

            for i in fetch_my_data:
                if i.raqam == "receive":
                    total_receive += int(i.payment)
                elif i.raqam == "loan":
                    total_loan += int(i.payment)
                else:
                    if i.voucher_id == bill_is:
                        pass
                    else:
                        total_receive += int(i.jama_raqam)
                        total_loan += int(i.udhaar)
                        check_kar = ["Items", "Price", "Quantity", "Discount"]
                        description_tha_mera = ""
                        bill_is = i.voucher_id
                        data_tha_mera = i.description
                        data_tha_mera = data_tha_mera.split("/")
                        for data, tha in zip(data_tha_mera, check_kar):
                            description_tha_mera += f" {tha}: {data} / "

                        newbill.append({"date": i.date, "voucher_id": i.voucher_id,
                                        "description": description_tha_mera,
                                        "jama_raqam": i.jama_raqam, "udhaar": i.udhaar})

            total_net_amount = fetch_old_udhaar
            # total_loan - total_receive

            return render_template("khata.html", data=fetch_my_data, name=name,
                                   dates=current_day, month=current_month, year=current_year,
                                   total_receive=total_receive, total_loan=total_loan,
                                   total_net_amount=total_net_amount, old_udhaar=fetch_old_udhaar,
                                   other_data_is=newbill)

        fetch_users_data = addcustomer.query.filter_by().all()
        return render_template("khata_pop.html", items=fetch_users_data,
                               dates=current_day, month=current_month, year=current_year)
    else:
        return redirect("/")


@app.route("/search-loan-voucher", methods=['GET', 'POST'])
def searchLoanVoucher():
    if "username" in session:
        if request.method == 'POST':
            voucher = request.form.get("myVouch")

            fetchVouch = loanpayment.query.filter_by(voucher_id=voucher).all()
            fetch_addcustomer = addcustomer.query.filter_by().all()
            fetch_loan_payment = loanpayment.query.filter_by().all()
            bill_no = fetchVouch[0].voucher_id

            return render_template("show_loan_voucher.html", dates=current_day,
                                   month=current_month, year=current_year, voucher_id=bill_no,
                                   users=fetch_addcustomer, backData=fetch_loan_payment)
        return render_template("search_loan_voucher.html")
    else:
        return redirect("/")


@app.route("/search-receive-voucher", methods=['GET', 'POST'])
def searchReceiveVoucher():
    if "username" in session:
        if request.method == 'POST':
            voucher = request.form.get("myVouch")

            fetchVouch = receivepayment.query.filter_by(voucher_id=voucher).all()

            if fetchVouch:
                fetch_addcustomer = addcustomer.query.filter_by().all()
                fetch_loan_payment = receivepayment.query.filter_by().all()
                bill_no = fetchVouch[0].voucher_id

                return render_template("show_receive_voucher.html", dates=current_day,
                                       month=current_month, year=current_year, voucher_id=bill_no,
                                       users=fetch_addcustomer, backData=fetch_loan_payment)
            else:
                return render_template("search_receive_payment.html")
        return render_template("search_receive_payment.html")
    else:
        return redirect("/")


@app.route("/expense", methods=['GET', 'POST'])
def expensePage():
    if "username" in session:
        return render_template("Expense_payment.html")
    else:
        return redirect("/")


@app.route("/search-sale-invoice", methods=['GET', 'POST'])
def searchSaleInvoice():
    if "username" in session:
        if request.method == 'POST':
            bill_no_is = request.form.get("bill-no")

            fetch_sale_invoice = sale_invoice.query.filter_by(bill_no=bill_no_is).all()
            fetch_users_data = addcustomer.query.filter_by().all()
            fetch_items_data = additem.query.filter_by().all()

            user_name = ""
            old = 0
            if fetch_sale_invoice:
                user_name = fetch_sale_invoice[0].customer_name

                user_ = addcustomer.query.filter_by(name=user_name).first()

                fetch_name_data = addcustomer.query.filter_by(name=user_name).first()
                prev_amount = fetch_name_data.old_udhaar

                return render_template("show_sale_invoice.html", name=user_name,
                                       year=current_year, month=current_month, date=current_day,
                                       data_is_data=fetch_sale_invoice, bill_no=bill_no_is,
                                       myAllData=fetch_sale_invoice, users=fetch_users_data,
                                       items=fetch_items_data, prev=prev_amount, tt=user_.old_udhaar)

        return render_template("search_sale_invoice.html")
    else:
        return redirect("/")


@app.route("/search-purchase-invoice", methods=['GET', 'POST'])
def searchPurchaseInvoice():
    if "username" in session:
        if request.method == 'POST':
            bill_no_is = request.form.get("bill-no")

            fetch_sale_invoice = purchase_invoice.query.filter_by(bill_no=bill_no_is).all()
            fetch_users_data = addcustomer.query.filter_by().all()
            fetch_items_data = additem.query.filter_by().all()

            user_name = ""
            old = 0
            if fetch_sale_invoice:
                user_name = fetch_sale_invoice[0].customer_name

                user_ = addcustomer.query.filter_by(name=user_name).first()

                fetch_name_data = addcustomer.query.filter_by(name=user_name).first()
                prev_amount = fetch_name_data.old_udhaar

                return render_template("show_purchase_invoice.html", name=user_name,
                                       year=current_year, month=current_month, date=current_day,
                                       data_is_data=fetch_sale_invoice, bill_no=bill_no_is,
                                       myAllData=fetch_sale_invoice, users=fetch_users_data,
                                       items=fetch_items_data, prev=prev_amount, tt=user_.old_udhaar)

        return render_template("search_purchase_invoice.html")
    else:
        return redirect("/")


# @app.route("/show-sale-invoice", methods=['POST'])
# def showSaleInvoice():
#     try:
#         data = request.json
#         bill_no = data['bill']
#         fetch_sale_invoice = sale_invoice.query.filter_by(bill_no=bill_no).all()
#         print(fetch_sale_invoice)
#
#         return jsonify({'data_dict': fetch_sale_invoice})
#     except Exception as e:
#         # Handle exceptions and respond with an error message
#         response = {'status': 'error', 'message': str(e)}
#         return jsonify(response), 500


@app.route('/save_data', methods=['POST'])
def save_data():
    try:
        data = request.json

        fetch_sale_invoice = sale_invoice.query.filter_by().all()

        if len(fetch_sale_invoice) <= 0:
            bill_no = 1
        else:
            bill_no = int(fetch_sale_invoice[::-1][0].bill_no) + 1

        save_sale_invoice_data(data, bill_no)

        # Respond with success message or any relevant information
        response = {'status': 'success', 'message': 'Data saved successfully'}
        return redirect("/sale-invoice")
    except Exception as e:
        # Handle exceptions and respond with an error message
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route('/save_data_purchase', methods=['POST'])
def save_data_purchase():
    try:
        data = request.json

        fetch_sale_invoice = purchase_invoice.query.filter_by().all()

        if len(fetch_sale_invoice) <= 0:
            bill_no = 2000
        else:
            bill_no = int(fetch_sale_invoice[::-1][0].bill_no) + 1

        save_purchase_invoice_data(data, bill_no)

        # Respond with success message or any relevant information
        response = {'status': 'success', 'message': 'Data saved successfully'}
        return redirect("/purchase-invoice")
    except Exception as e:
        # Handle exceptions and respond with an error message
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


def save_purchase_invoice_data(data, bill_no):
    prev_amount = data[0]['previous_amount']
    # prev_tha = data[0]["old_is_gold"]

    fetch_sale_invoice = purchase_invoice.query.filter_by().all()
    fetch_add_custmer = addcustomer.query.filter_by(name=data[0]["user_name"]).first()

    if fetch_add_custmer:
        fetch_add_custmer.old_udhaar = prev_amount
        # fetch_add_custmer.old_udhaar = prev_tha
        db.session.commit()

    value = 0

    for i in data:
        add_data = purchase_invoice(customer_name=i['user_name'], item_name=i['item_name'],
                                    quantity=i['item_quantity'], price=i['item_rate'],
                                    discount=i['item_discount'], total_amount=i['total_amount'],
                                    previous_amount=i['previous_amount'], bill_no=bill_no,
                                    jama_raqam=i['jama_raqam'], )

        db.session.add(add_data)
        db.session.commit()

        add_new_data = loan_receive_payment(name=i['user_name'], payment=i['total_amount'],
                                            description=f"{i['item_name']}/{i['item_quantity']}/{i['item_rate']}/{i['item_discount']}",
                                            date=current_date, voucher_id=bill_no, raqam="invoice",
                                            jama_raqam=i['jama_raqam'], udhaar=i['previous_amount'])
        db.session.add(add_new_data)
        db.session.commit()


def save_sale_invoice_data(data, bill_no):
    prev_amount = data[0]['previous_amount']
    # prev_tha = data[0]["old_is_gold"]

    fetch_sale_invoice = sale_invoice.query.filter_by().all()
    fetch_add_custmer = addcustomer.query.filter_by(name=data[0]["user_name"]).first()

    if fetch_add_custmer:
        fetch_add_custmer.old_udhaar = prev_amount
        # fetch_add_custmer.old_udhaar = prev_tha
        db.session.commit()

    value = 0

    for i in data:
        add_data = sale_invoice(customer_name=i['user_name'], item_name=i['item_name'],
                                quantity=i['item_quantity'], price=i['item_rate'],
                                discount=i['item_discount'], total_amount=i['total_amount'],
                                previous_amount=i['previous_amount'], bill_no=bill_no,
                                jama_raqam=i['jama_raqam'], )

        db.session.add(add_data)
        db.session.commit()

        add_new_data = loan_receive_payment(name=i['user_name'], payment=i['total_amount'],
                                            description=f"{i['item_name']}/{i['item_quantity']}/{i['item_rate']}/{i['item_discount']}",
                                            date=current_date, voucher_id=bill_no, raqam="invoice",
                                            jama_raqam=i['jama_raqam'], udhaar=i['previous_amount'])
        db.session.add(add_new_data)
        db.session.commit()



@app.route('/save_loan_payment', methods=['POST'])
def save_loan_data():
    try:
        data = request.json
        fetch_old_khatta_users = loanpayment.query.filter_by().all()

        if len(fetch_old_khatta_users) <= 0:
            voucher_id = 3000
        else:
            voucher_id = int(fetch_old_khatta_users[::-1][0].voucher_id) + 1

        addLoanUsers(voucher_id, data)

        # Respond with success message or any relevant information
        response = {'status': 'success', 'message': 'Data saved successfully'}
        return redirect("/loan-payment")
    except Exception as e:
        # Handle exceptions and respond with an error message
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route('/save_receive_payment', methods=['POST'])
def save_receive_data():
    try:
        data = request.json  # Assuming data is sent in JSON format
        # Perform operations to save data to your Flash backend
        fetch_old_khatta_users = receivepayment.query.filter_by().all()

        if len(fetch_old_khatta_users) <= 0:
            voucher_id = 4000
        else:
            voucher_id = int(fetch_old_khatta_users[::-1][0].voucher_id) + 1

        removeLoanUsers(voucher_id, data)

        # Respond with success message or any relevant information
        response = {'status': 'success', 'message': 'Data saved successfully'}
        return redirect("/receive-payment")
    except Exception as e:
        # Handle exceptions and respond with an error message
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


def removeLoanUsers(voucher_id, data):
    for i in data:
        fetch_add_customer = addcustomer.query.filter_by(name=i['user_name']).first()
        if fetch_add_customer:
            fetch_add_customer.old_udhaar = int(fetch_add_customer.old_udhaar) - int(i['payment'])
            add_data = receivepayment(name=i['user_name'], payment=i['payment'],
                                      description=i['description'], voucher_id=voucher_id)
            db.session.add(add_data)
            db.session.commit()

            add_data = loan_receive_payment(name=i['user_name'], payment=i['payment'],
                                            description=i['description'], voucher_id=voucher_id, raqam="receive",
                                            date=current_date, jama_raqam=0, udhaar=0)
            db.session.add(add_data)
            db.session.commit()


def addLoanUsers(voucher_id, data):
    for i in data:
        fetch_add_customer = addcustomer.query.filter_by(name=i['user_name']).first()
        if fetch_add_customer:
            fetch_add_customer.old_udhaar = int(fetch_add_customer.old_udhaar) + int(i['payment'])
            add_data = loanpayment(name=i['user_name'], payment=i['payment'],
                                   description=i['description'], voucher_id=voucher_id)
            db.session.add(add_data)
            db.session.commit()

            add_data = loan_receive_payment(name=i['user_name'], payment=i['payment'],
                                            description=i['description'], voucher_id=voucher_id, raqam="loan",
                                            date=current_date, jama_raqam=0, udhaar=0)
            db.session.add(add_data)
            db.session.commit()


@app.route("/change-sale-invoice", methods=['POST'])
def changeSaleInvoice():
    try:
        data = request.json
        bill_no = data[0]['bill_no']
        prev_amount = data[0]['previous_amount']
        # prev_amount_thi = data[0]['old_is_gold']
        name = data[0]['user_name']
        fetch_old_udhaar = addcustomer.query.filter_by(name=name).first()

        fetch_old_udhaar.old_udhaar = prev_amount

        fetch_data_bill_no = sale_invoice.query.filter_by(bill_no=bill_no).all()
        fetch_receive_loan_payment = loan_receive_payment.query.filter_by(voucher_id=bill_no)

        for i in fetch_data_bill_no:
            db.session.delete(i)
            db.session.commit()

        for i in fetch_receive_loan_payment:
            db.session.delete(i)
            db.session.commit()

        for i in data:
            add_data = sale_invoice(customer_name=i['user_name'], item_name=i['item_name'],
                                    quantity=i['item_quantity'], price=i['item_rate'],
                                    discount=i['item_discount'], total_amount=i['total_amount'],
                                    previous_amount=i['previous_amount'], bill_no=i['bill_no'],
                                    jama_raqam=i['jama_raqam'])
            db.session.add(add_data)
            db.session.commit()

            add_new_data = loan_receive_payment(name=i['user_name'], payment=i['total_amount'],
                                                description=f"{i['item_name']}/{i['item_quantity']}/{i['item_rate']}/{i['item_discount']}",
                                                date=current_date, voucher_id=bill_no, raqam="invoice",
                                                jama_raqam=i['jama_raqam'], udhaar=i['previous_amount'])
            db.session.add(add_new_data)
            db.session.commit()

        return redirect("/search-sale-invoice")
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route("/change-purchase-invoice", methods=['POST'])
def changePurchaseInvoice():
    try:
        data = request.json
        bill_no = data[0]['bill_no']
        prev_amount = data[0]['previous_amount']
        # prev_amount_thi = data[0]['old_is_gold']
        name = data[0]['user_name']
        fetch_old_udhaar = addcustomer.query.filter_by(name=name).first()

        fetch_old_udhaar.old_udhaar = prev_amount

        fetch_data_bill_no = purchase_invoice.query.filter_by(bill_no=bill_no).all()
        fetch_receive_loan_payment = loan_receive_payment.query.filter_by(voucher_id=bill_no)

        for i in fetch_data_bill_no:
            db.session.delete(i)
            db.session.commit()

        for i in fetch_receive_loan_payment:
            db.session.delete(i)
            db.session.commit()

        for i in data:
            add_data = purchase_invoice(customer_name=i['user_name'], item_name=i['item_name'],
                                        quantity=i['item_quantity'], price=i['item_rate'],
                                        discount=i['item_discount'], total_amount=i['total_amount'],
                                        previous_amount=i['previous_amount'], bill_no=i['bill_no'],
                                        jama_raqam=i['jama_raqam'])
            db.session.add(add_data)
            db.session.commit()

            add_new_data = loan_receive_payment(name=i['user_name'], payment=i['total_amount'],
                                                description=f"{i['item_name']}/{i['item_quantity']}/{i['item_rate']}/{i['item_discount']}",
                                                date=current_date, voucher_id=bill_no, raqam="invoice",
                                                jama_raqam=i['jama_raqam'], udhaar=i['previous_amount'])
            db.session.add(add_new_data)
            db.session.commit()

        return redirect("/search-purchase-invoice")
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route("/change_loan_payment", methods=['POST'])
def changeLoanPayment():
    try:
        data = request.json
        voucherId = data[0]['voucher_id']

        fetch_loan_data_is = loanpayment.query.filter_by().all()
        fetch_receive_loan_payment_is = loan_receive_payment.query.filter_by().all()

        fetch_loan_data = loanpayment.query.filter_by(voucher_id=voucherId).all()
        fetch_loan_payment = loan_receive_payment.query.filter_by(voucher_id=voucherId).all()

        for i in fetch_loan_data:
            db.session.delete(i)
            db.session.commit()

        for i in fetch_loan_payment:
            db.session.delete(i)
            db.session.commit()

        for i in data:
            fetch_add_customer = addcustomer.query.filter_by(name=i['user_name']).first()
            udhaar_is = int(fetch_add_customer.old_udhaar)
            udhaar_is += int(i['payment'])
            fetch_add_customer.old_udhaar = 0
            fetch_add_customer.old_udhaar = udhaar_is

            add_data = loanpayment(name=i['user_name'], payment=i['payment'], description=i['description'],
                                   voucher_id=voucherId, date=current_date)
            db.session.add(add_data)
            db.session.commit()

            dd_data = loan_receive_payment(name=i['user_name'], payment=i['payment'], description=i['description'],
                                           voucher_id=voucherId, date=current_date, raqam="loan", jama_raqam=0, udhaar=0)
            db.session.add(dd_data)
            db.session.commit()

        return redirect("/search-loan-voucher")
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route("/change_receive_payment", methods=['POST'])
def changeReceivePayment():
    try:
        data = request.json
        voucherId = data[0]['voucher_id']

        fetch_loan_data_is = receivepayment.query.filter_by().all()
        fetch_receive_loan_payment_is = loan_receive_payment.query.filter_by().all()

        fetch_loan_data = receivepayment.query.filter_by(voucher_id=voucherId).all()

        if fetch_loan_data:
            fetch_loan_payment = loan_receive_payment.query.filter_by(voucher_id=voucherId).all()

            for i in fetch_loan_data:
                db.session.delete(i)
                db.session.commit()

            for i in fetch_loan_payment:
                db.session.delete(i)
                db.session.commit()

            for i in data:
                fetch_add_customer = addcustomer.query.filter_by(name=i['user_name']).first()
                udhaar_is = int(fetch_add_customer.old_udhaar)
                udhaar_is -= int(i['payment'])
                fetch_add_customer.old_udhaar = 0
                fetch_add_customer.old_udhaar = udhaar_is

                add_data = receivepayment(name=i['user_name'], payment=i['payment'], description=i['description'],
                                          voucher_id=voucherId, date=current_date)
                db.session.add(add_data)
                db.session.commit()

                dd_data = loan_receive_payment(name=i['user_name'], payment=i['payment'],
                                               description=i['description'], voucher_id=voucherId,
                                               date=current_date, raqam="receive", jama_raqam=0, udhaar=0)
                db.session.add(dd_data)
                db.session.commit()

            return redirect("/search-receive-voucher")
        else:
            return redirect("/search-receive-voucher")
    except Exception as e:
        response = {'status': 'error', 'message': str(e)}
        return jsonify(response), 500


@app.route("/loan-list")
def loanList():
    if "username" in session:
        fetch_users_data = addcustomer.query.filter_by().all()
        return render_template("loan_list.html", data=fetch_users_data)
    else:
        return redirect("/")


# @app.route("/search-online-amount", methods=['GET', 'POST'])
# def searchOnlinePayment():
#     if "username" in session:
#         if request.method == 'POST':
#             bill_no = request.form.get("bill-no")
#             fetch_online_payment = online_payment.query.filter_by(bill_no=bill_no).all()

#             if fetch_online_payment:
#                 return render_template("show_online_amount.html", data=fetch_online_payment,
#                                        year=current_year, month=current_month, date=current_day, voucher_id=bill_no)


#         return render_template("search_online_payment.html")
#     else:
#         return redirect("/")


# @app.route('/change_online_payment', methods=['POST'])
# def changeOnlinePayment():
#     try:
#         data = request.json
#         print(data)
#     except Exception as error:
#         pass



app.run(debug=True)

